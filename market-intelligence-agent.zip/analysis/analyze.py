"""Internal-knowledge-base analysis of the Kaggle 'Global AI Job Market & Salary Trends 2025' files.
Run: python3 analysis/analyze.py   (from repo root). Outputs: outputs/metrics.json + outputs/charts/*.png
File A = data/ai_job_dataset.csv (19 cols); File B = data/ai_job_dataset1.csv (20 cols, has salary_local).
B is the primary file; A is used as an independent replication check."""
import json, pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
A = pd.read_csv("data/ai_job_dataset.csv"); B = pd.read_csv("data/ai_job_dataset1.csv")
out = {}

def prep(d):
    d = d.copy(); d["posting_date"] = pd.to_datetime(d.posting_date)
    d["month"] = d.posting_date.dt.to_period("M").astype(str)
    d["skills"] = d.required_skills.str.split(r",\s*")
    return d
A, B = prep(A), prep(B)

def top_skills(d, n=15):
    s = d.explode("skills").groupby("skills").agg(postings=("job_id","count"), med_salary=("salary_usd","median"))
    s["share_pct"] = (s.postings/len(d)*100).round(1)
    return s.sort_values("postings", ascending=False).head(n)

def summary(d):
    r = {}
    r["rows"] = len(d)
    r["median_salary"] = float(d.salary_usd.median()); r["mean_salary"] = float(d.salary_usd.mean())
    r["by_level"] = d.groupby("experience_level").salary_usd.median().round(0).to_dict()
    r["by_country_median"] = d.groupby("company_location").salary_usd.median().sort_values(ascending=False).round(0).to_dict()
    r["by_title_median"] = d.groupby("job_title").salary_usd.median().sort_values(ascending=False).round(0).to_dict()
    r["by_industry_median"] = d.groupby("industry").salary_usd.median().sort_values(ascending=False).round(0).to_dict()
    r["by_size_median"] = d.groupby("company_size").salary_usd.median().round(0).to_dict()
    r["by_education_median"] = d.groupby("education_required").salary_usd.median().round(0).to_dict()
    r["by_remote_median"] = d.groupby("remote_ratio").salary_usd.median().round(0).to_dict()
    r["remote_mix_pct"] = (d.remote_ratio.value_counts(normalize=True)*100).round(1).to_dict()
    r["employment_mix_pct"] = (d.employment_type.value_counts(normalize=True)*100).round(1).to_dict()
    r["level_mix_pct"] = (d.experience_level.value_counts(normalize=True)*100).round(1).to_dict()
    r["postings_by_country"] = d.company_location.value_counts().to_dict()
    r["postings_by_title"] = d.job_title.value_counts().to_dict()
    r["postings_by_industry"] = d.industry.value_counts().to_dict()
    r["top_companies"] = d.company_name.value_counts().head(10).to_dict()
    r["top_skills"] = top_skills(d).reset_index().to_dict("records")
    r["corr_exp_salary"] = round(float(d.years_experience.corr(d.salary_usd)),3)
    r["corr_benefits_salary"] = round(float(d.benefits_score.corr(d.salary_usd)),3)
    m = d.groupby("month").agg(postings=("job_id","count"), med=("salary_usd","median"))
    r["monthly"] = {k: {"postings": int(v.postings), "median_salary": float(v.med)} for k, v in m.iterrows()}
    # skill premium: median salary of postings requiring skill vs those that do not
    prem = {}
    for sk in top_skills(d, 30).index:
        has = d.skills.apply(lambda l: sk in l)
        prem[sk] = round(float(d[has].salary_usd.median()/d[~has].salary_usd.median()-1)*100, 1)
    r["skill_premium_pct"] = dict(sorted(prem.items(), key=lambda x: -x[1]))
    # within-level skill premium (controls for seniority)
    adj = {}
    for sk in prem:
        has = d.skills.apply(lambda l: sk in l)
        vals = []
        for lv, g in d.groupby("experience_level"):
            h = has[g.index]
            if h.sum() > 30 and (~h).sum() > 30: vals.append(g[h].salary_usd.median()/g[~h].salary_usd.median()-1)
        adj[sk] = round(float(np.mean(vals))*100, 1)
    r["skill_premium_within_level_pct"] = dict(sorted(adj.items(), key=lambda x: -x[1]))
    # dispersion of category counts: how uniform is the data? (coefficient of variation)
    for col in ["company_location","job_title","industry"]:
        c = d[col].value_counts(); r[f"cv_{col}"] = round(float(c.std()/c.mean()),3)
    # salary USD per currency sanity
    r["salary_by_currency_median"] = d.groupby("salary_currency").salary_usd.median().round(0).to_dict()
    return r

out["B_primary"] = summary(B); out["A_replication"] = summary(A)
# Replication: do rankings agree between the two independent files?
def rank_corr(key):
    a = pd.Series(out["A_replication"][key]); b = pd.Series(out["B_primary"][key])
    j = a.index.intersection(b.index)
    return round(float(a[j].rank().corr(b[j].rank())),3), len(j)
out["replication"] = {k: rank_corr(k) for k in ["by_country_median","by_title_median","by_industry_median"]}
sa = pd.Series(out["A_replication"]["skill_premium_pct"]); sb = pd.Series(out["B_primary"]["skill_premium_pct"])
j = sa.index.intersection(sb.index); out["replication"]["skill_premium"] = (round(float(sa[j].rank().corr(sb[j].rank())),3), len(j))
out["replication"]["level_ratio_EX_to_EN"] = {"A": round(out["A_replication"]["by_level"]["EX"]/out["A_replication"]["by_level"]["EN"],2),
                                               "B": round(out["B_primary"]["by_level"]["EX"]/out["B_primary"]["by_level"]["EN"],2)}
# Local-currency sanity (B)
B["fx"] = B.salary_local/B.salary_usd
out["fx_implied"] = B.groupby("salary_currency").fx.median().round(3).to_dict()
json.dump(out, open("outputs/metrics.json","w"), indent=1, default=str)

# ---- charts ----
plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False,"figure.dpi":140})
C = "#2f5d8a"
r = out["B_primary"]
def barh(series, title, fn, fmt="${:,.0f}", n=12):
    s = pd.Series(series).head(n)[::-1]; fig, ax = plt.subplots(figsize=(7,4.2))
    ax.barh(s.index, s.values, color=C); ax.set_title(title, loc="left", fontweight="bold")
    for i,v in enumerate(s.values): ax.text(v, i, " "+fmt.format(v), va="center", fontsize=8)
    ax.set_xlim(0, s.max()*1.18); fig.tight_layout(); fig.savefig(f"outputs/charts/{fn}.png"); plt.close(fig)
barh(r["by_country_median"], "Median salary (USD) by company location", "01_salary_by_country")
barh(r["by_title_median"], "Median salary (USD) by job title", "02_salary_by_title")
barh({s["skills"]: s["share_pct"] for s in r["top_skills"]}, "Share of postings requiring each skill (%)", "03_top_skills", "{:.1f}%")
barh(r["skill_premium_within_level_pct"], "Skill salary premium, within seniority level (%)", "04_skill_premium", "{:+.1f}%", 10)
fig, ax = plt.subplots(figsize=(7,3.6)); lv = ["EN","MI","SE","EX"]
ax.bar(lv, [r["by_level"][l] for l in lv], color=C)
for i,l in enumerate(lv): ax.text(i, r["by_level"][l], f"${r['by_level'][l]:,.0f}", ha="center", va="bottom", fontsize=8)
ax.set_title("Median salary by experience level", loc="left", fontweight="bold"); fig.tight_layout(); fig.savefig("outputs/charts/05_salary_by_level.png"); plt.close(fig)
m = pd.DataFrame(r["monthly"]).T; fig, ax = plt.subplots(figsize=(7,3.6))
ax.plot(m.index, m.postings, color=C, marker="o"); ax.set_title("Postings per month (File B)", loc="left", fontweight="bold")
ax.set_ylim(0, m.postings.max()*1.2); plt.xticks(rotation=60, fontsize=8); fig.tight_layout(); fig.savefig("outputs/charts/06_postings_trend.png"); plt.close(fig)
print(json.dumps({k: out[k] for k in ["replication","fx_implied"]}, indent=1))
for k in ["B_primary","A_replication"]:
    o = out[k]; print(k, o["median_salary"], o["by_level"], o["remote_mix_pct"], o["by_remote_median"], o["by_size_median"], o["by_education_median"], o["corr_exp_salary"], o["corr_benefits_salary"], o["cv_company_location"], o["cv_job_title"], o["cv_industry"])
    print(list(o["by_country_median"].items())[:5], list(o["by_country_median"].items())[-3:])
    print(list(o["by_title_median"].items())[:4], list(o["by_title_median"].items())[-3:])
    print(list(o["by_industry_median"].items())[:3], list(o["by_industry_median"].items())[-2:])
    print([(s["skills"], s["share_pct"]) for s in o["top_skills"][:8]])
    print(list(o["skill_premium_within_level_pct"].items())[:5], list(o["skill_premium_within_level_pct"].items())[-3:])
    print(o["monthly"]["2024-01"], o["monthly"]["2025-03"], o["monthly"]["2025-04"])
