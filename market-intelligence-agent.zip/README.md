# Market Intelligence Agent — Global AI & Data Talent Market

An Amazon QuickSuite Market Intelligence Agent project: a Kaggle dataset of AI job postings as the internal knowledge base, external signals from research, a market analysis, a leadership brief, and a reliability/confidence check. This repo holds the data, reproducible analysis, reference deliverables and the exact agent configuration and prompts.

## Headline findings
1. AI-skill demand is growing ~8× faster than the overall job market (PwC: +69% vs +9%) — **High** confidence (direction).
2. Seniority is the biggest pay lever: EX ≈ 3× EN median salary in both dataset files — Medium.
3. A stable high-pay tier (Switzerland, Norway, Denmark, US) pays 15–50% above the median; the rest of the ranking doesn't replicate across files — Medium/Low.
4. Python/SQL are the most-requested skills, but no skill shows a reliable pay premium — Medium/Low.
5. Entry-level pipelines are under pressure (Stanford AI Index, PwC) — Medium.

**Important:** the Kaggle files show synthetic-data signatures (uniform category shares, constant FX, 16 generic employers) and the two files are independent samples that share job IDs. The reliability evaluation caps dataset-only insights at Medium for that reason.

## Project steps → repo files

| Assignment step | Where |
|---|---|
| 1. Kaggle dataset | `data/ai_job_dataset.csv`, `data/ai_job_dataset1.csv`; profile in `docs/01_dataset_profile.md` |
| 2–3. Space + agent | `agent/agent_config.md` (name, purpose, instructions) · `docs/05_quicksuite_runbook.md` |
| 4. Quick Research | `research/quick_research_objective.md` (paste into QuickSuite) · `research/external_signals.md` |
| 5. Market Analysis | `docs/02_market_analysis.md` · `analysis/analyze.py` → `outputs/` |
| 6. Reliability | `docs/03_reliability_evaluation.md` |
| 7. Brief | `docs/04_market_intelligence_brief.md` |
| 8. Space + submission | `docs/05_quicksuite_runbook.md` |

## Reproduce the analysis
```bash
pip install -r requirements.txt
python3 analysis/analyze.py      # writes outputs/metrics.json and outputs/charts/*.png
```

## Status / honesty notes
- QuickSuite steps (create Space, agent, run Quick Research, share) must be done in QuickSuite — follow `docs/05_quicksuite_runbook.md`. The documents here are reference versions; submit the agent's own outputs.
- `research/external_signals.md` came from web research with sources and quality flags, not from QuickSuite Quick Research. One source (Indeed Hiring Lab) could not be read directly.
- Kaggle URL still to be added in `docs/01_dataset_profile.md`.

## Layout
```
data/        raw Kaggle CSVs (unmodified)
analysis/    analyze.py
outputs/     metrics.json, charts/
research/    Quick Research objective + external signals
docs/        dataset profile, analysis, reliability, brief, runbook
agent/       agent configuration and prompts
```
