# Quick Research objective (paste into QuickSuite → Quick Research)

> The file `external_signals.md` in this folder was produced by web research in this repo's build session, as a stand-in so the analysis is reproducible. **Run the same objective in QuickSuite Quick Research and save that output as `research/quicksuite_quick_research_output.md` (or into your Space) — the assignment requires the QuickSuite run.**

## Objective

Research the 2025–2026 global market for AI / ML / data roles, to give external context for an internal dataset of 15,000 AI job postings (Jan 2024 – Apr 2025, 20 countries, 20 job titles, 15 industries).

Answer, with sources, dates and exact figures:

1. **Demand growth** – how fast are job postings requiring AI skills growing, vs. the overall job market?
2. **Pay** – what is the wage premium for AI skills, and how does pay vary by country/region (incl. India, US, Europe, Singapore)?
3. **Skills** – which skills appear most often in AI job postings (Python, SQL, cloud, LLM/agentic AI), and which are growing fastest?
4. **Work model** – what share of AI roles are remote / hybrid / on-site?
5. **Entry-level and talent supply** – what is happening to junior hiring, and is there a talent shortage (incl. India GCCs)?
6. **Competitive landscape** – who competes for AI talent (big tech, GCCs, startups, consultancies) and what are they paying?

Constraints: prefer primary sources (PwC, Lightcast, Indeed Hiring Lab, Stanford AI Index, LinkedIn, Levels.fyi, government data). Flag any figure that only appears in a secondary source or has no stated methodology. Give publication date and data period for every figure.
