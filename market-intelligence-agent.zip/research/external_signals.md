# External signals (web research, retrieved 2026-11-02)

Source-quality key: **P** = primary publisher page read directly · **S** = secondary / re-reported · **U** = no cited methodology (treat as unverified).

## 1. Demand growth

| Signal | Figure | Source | Quality |
|---|---|---|---|
| Growth in jobs requiring specific AI skills | **+69%** vs **+9%** for the overall job market; AI jobs ≈ 2× the 2024 level | [PwC 2026 Global AI Jobs Barometer](https://pwc.com/gx/en/news-room/press-releases/2026/pwc-2026-ai-jobs-barometer.html) (>1 bn job ads, 27 countries; exact period not stated on page) | P |
| Share of US postings mentioning AI skills | **2.5%** (+55% YoY, +72% vs 2022). Lightcast's country table shows US at 2.6% — the page doesn't reconcile the two. | [Lightcast – Four takeaways from the 2026 Stanford AI Index](https://lightcast.io/resources/blog/stanford-ai-2026) | P |
| Agentic AI skills | 0.06% of postings (2024) → **0.23%** (2025), ~90,000 US postings | same Lightcast page | P |
| Jobseeker interest vs employer demand | Searches for AI roles were **<1% of job searches** in early 2026 – demand outpaces candidate interest | [PropertyCasualty360 (re-reporting Indeed Hiring Lab)](https://www.propertycasualty360.com/amp/2026/05/04/hiring-demand-for-ai-skills-outpaces-candidate-interest/); Indeed's own page could not be fetched from this environment | S |

## 2. Pay

| Signal | Figure | Source | Quality |
|---|---|---|---|
| AI-skills wage premium | **62%** average (57% prior year); **up to 118%** in some sectors, **16%** in government | PwC 2026 barometer (above) | P |
| Wage growth | 24% at AI-most-able companies vs 17% at least-exposed | PwC | P |
| India pay (annual, INR) | GenAI engineer: entry ≈ ₹12 lakh, 3–5 yrs ≈ ₹25 lakh, 8+ yrs ≈ ₹60 lakh; GCCs pay 12–20% above IT services; AI/data-science roles carry a 30–50% premium | [Business Today, 12 Jun 2026](https://www.businesstoday.in/technology/artificial-intelligence/story/indias-ai-talent-can-earn-rs60-lakh-a-year-heres-which-skills-pay-the-most-536404-2026-06-12) citing 1 Finance Global Economic Outlook 2026 / TeamLease RegTech | S |
| Remote vs. SF pay gap for AI engineers | narrowed to 12–15% (from 22–28% in 2022–23) | [Rework](https://resources.rework.com/news/ai-jobs-skills/remote-ai-roles-talent-geography-shift) | **U** |

## 3. Skills

| Signal | Figure | Source | Quality |
|---|---|---|---|
| Top specialised skill in AI postings, 2025 | **Python**, 258,674 US postings (+~30% vs 2024) | Lightcast (above) | P |
| Where AI skills are concentrated (share of postings requiring AI skills, 2025) | Singapore 4.77% · Hong Kong 3.5% · Luxembourg 3.4% · Spain 3.3% · US 2.6% | Lightcast | P |

## 4. Work model

| Signal | Figure | Source | Quality |
|---|---|---|---|
| Remote-first share of AI postings | **65%** in Q1 2026 (38% in Q1 2024); RTO moves cut applications ~47% | Rework (attributes to LinkedIn/Indeed/Glassdoor but gives no sample or method) | **U** |

## 5. Entry-level and talent supply

| Signal | Figure | Source | Quality |
|---|---|---|---|
| Early-career headcount | Software-developer and customer-support headcounts **fell for ages 22–25** (2021–2025) while most older groups grew (chart caption; no % on page) | [Stanford AI Index 2026 – Economy](https://hai.stanford.edu/ai-index/2026-ai-index-report/economy) | P |
| AI-exposed entry-level roles (US, 2.4 m jobs) | 7× more likely to require senior-type human skills; openings **+35% since 2019** vs **−10%** for other entry-level roles | PwC | P |
| Organisational AI adoption | **88%** of organisations in 2025 (55% in 2023); GenAI 53% adoption within 3 years | Stanford AI Index 2026 | P |
| Workforce expectations | 32% of organisations expect AI to *decrease* headcount next year, 13% increase, 43% little change | Stanford AI Index 2026 | P |
| India GCCs | AI/ML adoption 65% (FY19) → 86% (FY24); direct GCC jobs 2.0 m (2025) → 2.8 m (2030 proj.); AI could displace 2 m tech jobs yet create up to 4 m (projection) | Business Today / 1 Finance | S |

## 6. Competitive landscape (employers)

Not adequately covered by the sources above. Company names in the Kaggle file are generic (e.g. "TechCorp Inc") and cannot be mapped to real employers. **Gap — rerun in QuickSuite Quick Research with named competitors (big tech, GCCs, startups) if employer-level analysis is required.**

## Not retrieved / could not verify

- Indeed Hiring Lab's own posting-share figures (domain blocked in this environment).
- Any Levels.fyi or LinkedIn primary salary data.
- Stanford HAI "12 takeaways" page returned no body text.
