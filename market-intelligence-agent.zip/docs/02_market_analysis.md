# Market Analysis — Global AI / Data Talent Market

**Scope:** 15,000-posting Kaggle dataset (File B primary, File A replication; Jan 2024–Apr 2025) + external signals from `research/external_signals.md` (retrieved 2026-11-02).
**Question:** Where is pay and demand in the AI/data talent market concentrated, and what should a leadership team planning AI hiring/compensation conclude?
Evidence tags: **[DS]** dataset, **[EXT]** external research. Confidence ratings are justified in `03_reliability_evaluation.md`.

## 1. Competitive landscape summary

The dataset has no real employer identities (16 generic company names), so "competitors" are analysed as **market segments**, not firms.

| Segment (File B median salary, USD) | Value | Replicates in File A? |
|---|---|---|
| Switzerland / Norway / Denmark / United States | $154.9k / $142.3k / $137.6k / $123.8k (+44% / +33% / +28% / +15% vs. $107.3k overall median) | Yes — same four countries in the top 4–5 (+53% / +43% / +48% / +29%) |
| India / China | $38.3k / $50.4k (−64% / −53%) | **No** — A shows India $76.0k, China $76.5k |
| Large vs small companies (L vs S) | $122.0k vs $95.0k (**+28%**) | Yes (+28%) |
| Remote 0 / 50 / 100% | $106.5k / $108.5k / $107.1k | Yes — no effect in either file |
| Industry (spread top→bottom) | Automotive $112.7k → Finance $103.9k (8%) | No — rank order unrelated (ρ = −0.14) |
| Job title (spread top→bottom) | Data Engineer $112.5k → Data Analyst $103.2k (9%) | No — rank order barely related (ρ = 0.19) |

**External view of who competes for talent [EXT]:** employers in AI-exposed sectors show 24% wage growth vs 17% elsewhere (PwC); in India, GCCs pay 12–20% above IT-services firms and AI/data roles carry a 30–50% premium (Business Today/1 Finance). Named-employer coverage is a **gap** — rerun Quick Research with specific competitors.

## 2. Key trends and signals

1. **Seniority is the dominant pay driver [DS].** Median salary rises EN $66.5k → MI $91.6k → SE $128.5k → EX $197.4k (EX/EN = 2.97×; File A 2.94×). Years of experience correlates with salary at r = 0.74 (A: 0.74). Benefits score (r ≈ 0.00) and education (all levels within ±3% of each other; PhD is not highest) do not.
2. **A stable top tier of high-pay countries [DS].** Switzerland, Norway, Denmark and the US lead in both files; the middle and bottom of the ranking are not stable between files (Spearman ρ = 0.80 across 20 countries overall, driven by the top).
3. **Company size matters; remote status does not [DS].** Large firms pay ~28% more than small in both files; remote ratio and employment type show no salary difference.
4. **Python and SQL are the most-requested skills [DS + EXT].** Python appears in 30% of postings, SQL 23% (A: 29.7% / 22.7%); Lightcast independently finds Python the top specialised skill in 2025 AI postings (258,674 US postings, ~+30% YoY). **Individual skills carry no salary premium in the dataset** (within-seniority effects are −1.4% to +1.7%, and the ranking does not replicate: ρ = 0.15).
5. **Demand for AI skills is growing far faster than the overall market [EXT].** +69% in AI-skill jobs vs +9% overall (PwC); AI share of US postings 2.5% (+55% YoY); agentic-AI postings 0.06% → 0.23% (Lightcast). The dataset **cannot** show a trend: monthly postings are flat (842–1,021).
6. **Talent supply is two-sided [EXT].** Employers report demand outpacing candidate interest (AI roles <1% of job searches, early 2026), yet headcounts of software developers aged 22–25 fell 2021–2025 and 32% of organisations expect AI to reduce headcount (Stanford AI Index 2026). Early-career AI-exposed roles increasingly demand senior-type skills (PwC).

## 3. Opportunities and risks

**Opportunities**
- *Pay-band design on seniority first, geography second, firm size third.* These are the only structure the dataset supports robustly; the 3× EN→EX ladder and the +28% large-firm premium are directly usable as benchmarks (with the caveats below).
- *Skill-based hiring around Python/SQL fundamentals* is supported by two independent sources; paying specifically for individual tools is not.
- *India / emerging hubs:* external data shows strong GCC AI adoption (86% by FY24) and a 30–50% pay premium for AI/data roles [EXT]; the dataset's India figure is unreliable (see risk 2), so size this opportunity with external data only.

**Risks**
1. **Synthetic-data risk (high).** Near-uniform category shares, constant FX rates and 16 generic employers suggest generated data. Conclusions about real-world title, industry or skill premiums should not be drawn.
2. **Unstable sub-markets.** India and China medians flip between files (e.g. India $38k vs $76k), so low-cost-market salary benchmarks are unusable.
3. **Posting ≠ pay.** Advertised salaries differ from realised compensation and exclude equity/bonus.
4. **Demand-side blind spot.** No hires, applicants or time-to-fill; "demand" is inferred from postings only.
5. **Entry-level pressure [EXT].** Falling junior headcount in AI-exposed jobs means entry-level pipelines may be thinner than the postings suggest.

## 4. Supporting evidence index

| Claim | Dataset evidence | External evidence |
|---|---|---|
| Seniority ladder ≈ 3× | `outputs/charts/05_salary_by_level.png`, `metrics.json › by_level` | none retrieved |
| Top-tier countries | `01_salary_by_country.png` | Lightcast country skill-share (different metric: demand, not pay) |
| Large-firm premium | `metrics.json › by_size_median` | none retrieved |
| Python/SQL ubiquity | `03_top_skills.png` | Lightcast (Python #1) |
| No skill premium | `04_skill_premium.png` | PwC 62% premium is AI-vs-non-AI — **untestable** here (all postings are AI roles) |
| Demand surge | flat `06_postings_trend.png` (no signal) | PwC, Lightcast |
| Remote has no pay effect | `metrics.json › by_remote_median` | Rework: 65% of AI postings remote — **contradicts** the dataset's 33% and is itself unverified |
