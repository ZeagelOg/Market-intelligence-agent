# Dataset reference (internal knowledge base)

**Source:** Kaggle public dataset on global AI job-market & salary trends, downloaded as `archive_1.zip`, unmodified.
**Kaggle URL:** _TODO – add the exact dataset URL/author from your Kaggle download page before submitting._

| File | Rows | Cols | Notes |
|---|---|---|---|
| `data/ai_job_dataset.csv` (**File A**) | 15,000 | 19 | salaries in USD only |
| `data/ai_job_dataset1.csv` (**File B**) | 15,000 | 20 | adds `salary_local`; 8 currencies |

Both: postings dated 2024-01-01 → 2025-04-30; unique `job_id` (AI00001–AI15000); no missing values; no duplicate rows.

**Key finding on the files themselves:** A and B reuse the same `job_id`s, but their contents differ (0% matching `salary_usd`, ~5% matching job title/country). They are **two independent samples, not a version update** — so File B is used as the primary dataset and File A as an independent replication check.

## Columns
`job_id, job_title, salary_usd, salary_currency, [salary_local – B only], experience_level (EN/MI/SE/EX), employment_type (FT/PT/CT/FL), company_location, company_size (S/M/L), employee_residence, remote_ratio (0/50/100), required_skills (comma list), education_required, years_experience, industry, posting_date, application_deadline, job_description_length, benefits_score, company_name`

## What the dataset can and cannot represent
- **Is:** job *postings* with advertised salary — a demand-side snapshot.
- **Is not:** actual hires, total compensation, employer-level market share or a time series of demand (postings per month are flat at ~840–1,020).
- **Synthetic indicators:** category counts are almost perfectly uniform (20 countries/titles/industries each within ±4% of equal share; remote 0/50/100 each ≈ 33%; the four experience levels each ≈ 25%); exchange rates implied by `salary_local/salary_usd` are constant (EUR 0.85, GBP 0.75, JPY 110…); `company_name` is a small set of generic names. Treat the file as **illustrative/synthetic until its provenance is verified** (see `03_reliability_evaluation.md`).
