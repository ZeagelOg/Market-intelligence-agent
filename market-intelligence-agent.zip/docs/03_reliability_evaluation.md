# Reliability, Confidence & Limitations Evaluation

**Method.** (1) Every dataset insight was re-computed on a second, independent file (File A) — an insight "replicates" only if direction and rough size hold. (2) Each insight was checked against external sources and graded by source quality (P/S/U in `research/external_signals.md`). (3) Confidence: **High** = replicates *and* externally corroborated by primary sources; **Medium** = replicates or is corroborated, not both; **Low** = neither, or contradicted.

**Global caveat that caps everything:** the dataset shows synthetic-data signatures (near-uniform category shares, constant FX rates, 16 generic employers). Replication across A and B can reveal random noise but **cannot** rule out that both files come from the same generator, so no dataset-only insight is rated High.

## Insight-level evaluation

| # | Insight | Dataset evidence | External evidence | Gaps / assumptions | Confidence | What cannot be concluded |
|---|---|---|---|---|---|---|
| 1 | Seniority drives pay: EN→EX ≈ 3× | B: $66k→$197k (2.97×); A: 2.94×; r(years, salary) 0.74 in both | None retrieved | Real markets are less uniform; advertised pay only | **Medium** | Exact ladder multiples for any real employer or country |
| 2 | Switzerland, Norway, Denmark, US pay 15–50% above the median | Top 4 in both files; ρ = 0.80 overall | Lightcast ranks countries by AI-skill *share* (Singapore, HK, Luxembourg, Spain, US) — different metric, not pay | Cost-of-living, tax and currency effects ignored; salary_usd uses fixed FX | **Medium** (top tier) / **Low** (India, China, mid-table) | Any ranking below the top tier; India ($38k vs $76k) and China are inconsistent between files |
| 3 | Large firms pay ~28% more than small firms | +28% in both files | None retrieved | Size is a 3-bucket label; confounded with country/seniority not tested | **Low** | Causality; whether the premium holds within a seniority level |
| 4a | Python (30%) and SQL (23%) are the most-requested skills | Both files | Lightcast: Python top specialised skill, 258,674 US postings | Dataset skills are a fixed pool of ~25 tags; LLM/GenAI/agentic skills absent | **Medium** | Skill demand for LLM, agentic AI or other emerging skills (not in the dataset's vocabulary) |
| 4b | Individual skills carry no salary premium | Within-seniority effect −1.4…+1.7%; ranking does not replicate (ρ 0.15) | PwC's 62% premium is AI-vs-non-AI; **dataset has no non-AI comparison group** | A null result in synthetic data is not evidence of a null in reality | **Low** | Any claim about the premium for a particular skill — in either direction |
| 5 | AI-skill demand is growing much faster than the overall market | **Not testable** — monthly postings flat 842–1,021 | PwC (+69% vs +9%, >1 bn ads), Lightcast (+55% YoY share) — independent primary sources agree on direction | Different periods/definitions; PwC's period not stated on page; US-centric for Lightcast | **High** (direction) / **Medium** (magnitude) | Growth rate for any specific country or role; whether growth continues after 2026 |
| 6 | Remote status has no salary effect | Flat in both files ($106–109k) | Rework claims 65% of AI postings are remote (unverified); contradicts dataset's 33/33/33 split | Dataset remote split is almost certainly synthetic | **Low** | Anything about real remote-work pay or prevalence |
| 7 | Entry-level pipeline is under pressure | Not testable (EN is a uniform 24–25% of postings) | Stanford AI Index: headcount of ages 22–25 fell in software dev; PwC: entry-level AI-exposed roles require senior-type skills | Stanford gives no % on the page read; PwC data is US-only | **Medium** | Size of the decline; whether it applies outside the US or to data-analyst roles specifically |

## Cross-checks performed

| Check | Result |
|---|---|
| Overlap of A and B on `job_id` | 15,000 shared IDs, 0% matching salary → independent samples |
| Rank agreement A vs B: country / title / industry / skill premium | ρ = 0.80 / 0.19 / −0.14 / 0.15 → only country (top tier) replicates |
| Category uniformity (coefficient of variation of counts) | country 0.04, title 0.04, industry 0.02 → implausibly uniform for real postings |
| Implied FX (`salary_local/salary_usd`) | Constant: EUR 0.85, GBP 0.75, CHF 0.90, CAD 1.25, AUD 1.35, SGD 1.30, JPY 110 → no time variation, synthetic |
| External figures read from primary pages | PwC, Lightcast, Stanford HAI — read directly. Indeed Hiring Lab — **not** read (blocked); Rework — no methodology (U) |

## Known limitations
1. Synthetic/unknown provenance of the Kaggle files (verify the dataset page's description).
2. Postings-based, advertised salaries; no equity, bonus or realised pay.
3. Dataset period (Jan 2024–Apr 2025) predates the external 2025–2026 signals; temporal mismatch of 6–18 months.
4. No real employer names → competitive landscape is segment-level only.
5. External research here was a web-search stand-in; the QuickSuite Quick Research output should be compared against `external_signals.md` and any discrepancies noted.
6. No statistical significance tests or regression controls were run; the 28% size premium and country premiums are raw medians.
