# QuickSuite runbook & submission checklist

These steps happen inside Amazon QuickSuite and can't be automated from this repo. Everything you need to paste or upload is in the repo.

| # | Step | Do this | Artefact |
|---|---|---|---|
| 1 | Dataset | Already downloaded. Add the Kaggle URL to `docs/01_dataset_profile.md`. | `data/*.csv` (unmodified) |
| 2 | Space | QuickSuite → Spaces → Create space `Market Intelligence – Global AI Talent`. Upload both CSVs. | — |
| 3 | Agent | Agents → Create agent; name, purpose, instructions from `agent/agent_config.md`; attach the Space's dataset as knowledge; save. | agent link |
| 4 | Quick Research | Open Quick Research, paste `research/quick_research_objective.md`, run, **save the report to the Space**. Compare with `research/external_signals.md` and note differences. | Quick Research report |
| 5 | Market Analysis | In the agent, run the Step 5 prompt (agent_config.md) with the Quick Research output pasted. Save the response to the Space. Check it against `docs/02_market_analysis.md`. | Market Analysis |
| 6 | Reliability | Run the Step 6 prompt. If the agent rates anything High on dataset-only evidence, push back. | Reliability section |
| 7 | Brief | Run the Step 7 prompt. | Brief |
| 8 | Share | Add to the Space: dataset reference, Quick Research output, Market Analysis, Brief, reliability section. Order them as below. Share the Space with the instructor/reviewer. | Space link |

## Suggested Space layout (stakeholder can review in ~5 min)
1. **00 – Start here:** the Brief (`docs/04_...`)
2. **01 – Reliability & limitations** (`docs/03_...`)
3. **02 – Market Analysis** (`docs/02_...`)
4. **03 – Quick Research outputs** (QuickSuite report + `research/external_signals.md`)
5. **04 – Dataset reference** (`docs/01_...` + the two CSVs)
6. **05 – Agent** (link + `agent/agent_config.md`)

## Before you submit
- [ ] The agent exists and the dataset is attached as its knowledge source
- [ ] A **real** Quick Research run is saved in the Space
- [ ] The agent's own Market Analysis/Brief are in the Space (the files here are reference versions — use the agent's output, edited where it disagrees with the evidence)
- [ ] Space is shared with the grader; link tested in a private window
- [ ] Kaggle URL filled in; GitHub repo link added to the submission
